<?php

/**
 * Fired during plugin activation
 *
 * @link       www.shafeeamin.com
 * @since      1.0.0
 *
 * @package    Headerfootershafee
 * @subpackage Headerfootershafee/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Headerfootershafee
 * @subpackage Headerfootershafee/includes
 * @author     Shafee Amin <ibnaamin@usf.edu>
 */
class Headerfootershafee_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function activate() {

	}

}
