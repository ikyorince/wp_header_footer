<?php

/**
 * Fired during plugin deactivation
 *
 * @link       www.shafeeamin.com
 * @since      1.0.0
 *
 * @package    Headerfootershafee
 * @subpackage Headerfootershafee/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Headerfootershafee
 * @subpackage Headerfootershafee/includes
 * @author     Shafee Amin <ibnaamin@usf.edu>
 */
class Headerfootershafee_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
