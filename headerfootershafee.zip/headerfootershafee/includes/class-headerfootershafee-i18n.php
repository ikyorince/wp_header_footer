<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       www.shafeeamin.com
 * @since      1.0.0
 *
 * @package    Headerfootershafee
 * @subpackage Headerfootershafee/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Headerfootershafee
 * @subpackage Headerfootershafee/includes
 * @author     Shafee Amin <ibnaamin@usf.edu>
 */
class Headerfootershafee_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'headerfootershafee',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
